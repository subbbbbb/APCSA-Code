import math
print("Welcome to the area of a circle calculator!")
print("What is your radius?")
r = input()
print("The area of your circle is " + str(math.pi*float(r)**2))
