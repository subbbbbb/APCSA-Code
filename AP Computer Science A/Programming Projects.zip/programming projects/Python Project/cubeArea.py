print("Welcome to the surface area of a cube calculator!")
print("What is your side length?")
sideLength = input()
print(6*(float(sideLength)**2))
