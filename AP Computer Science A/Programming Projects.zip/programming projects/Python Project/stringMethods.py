yes = "champion of the world"
print(yes[1])  # indexOf in java
print(yes[2:5])  # substring in java
no = " CHAMPION OF THE WORLD "
print(no.strip())  # gets rid of the whitespace at the beginning and the end
print(len(yes))  # length in java
print(no.lower())  # returns lowercase version of the string
print(yes.upper())  # returns uppercase version of the string
print(yes.replace("o","e"))  # takes the first string, and replaces it with the next string (instances of it)
print(yes.split("of"))  # finds the string, then splits it up there

# using input() for strings
print("What is your name?")
x = input()
print("Hello",x)


