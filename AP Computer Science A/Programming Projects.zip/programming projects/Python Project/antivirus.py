import os.path
os.path.isfile()